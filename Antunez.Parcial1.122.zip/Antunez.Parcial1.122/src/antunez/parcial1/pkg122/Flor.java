
package antunez.parcial1.pkg122;


public class Flor extends Planta implements Aroma{
    
    private Temporada temporada;

    public Flor(String nombre, String ubicacion, String clima, Temporada temporada) {
        super(nombre, ubicacion, clima);
        this.temporada = temporada;
    }

    public Temporada getTemporada() {
        return temporada;
    }

    public void desprenderAroma() {
        System.out.println("La flor " + getNombre() + " esta desprendiendo aroma.");
    }

    @Override
    public String toString() {
        return super.toString() + ", Temporada de florecimiento: " + temporada;
    }
}

