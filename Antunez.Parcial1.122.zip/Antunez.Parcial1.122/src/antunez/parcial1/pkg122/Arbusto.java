
package antunez.parcial1.pkg122;


public class Arbusto extends Planta implements Podable{
    
    private static final int MIN_DENSIDAD = 0;
    private static final int MAX_DENSIDAD = 10;
    private int densidadFollaje;
    
    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        if(densidadFollaje < MIN_DENSIDAD || densidadFollaje > MAX_DENSIDAD) {
            throw new IllegalArgumentException("Densidad de follaje debe estar entre 1 y 10.");
        }
        this.densidadFollaje = densidadFollaje;
    }

    public void podar() {
        System.out.println("Podando arbusto " + getNombre());
    }
    

    @Override
    public String toString() {
        return super.toString() + ", Densidad del follaje: " + densidadFollaje;
    }
    
    
}

