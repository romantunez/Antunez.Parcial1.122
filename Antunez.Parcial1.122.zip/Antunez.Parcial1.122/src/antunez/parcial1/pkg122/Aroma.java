
package antunez.parcial1.pkg122;


public interface Aroma {
    void desprenderAroma();
}
