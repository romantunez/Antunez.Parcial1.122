
package antunez.parcial1.pkg122;

public class AntunezParcial1122 {


    public static void main(String[] args) {

        JardinBotanico jardin = new JardinBotanico();

        try { 
            // CASO DE PRUEBA 1 
            Arbol roble = new Arbol("Roble", "Zona Norte", "Templado", 15);
            jardin.agregarPlanta(roble);
            
            
            Arbol roble2 = new Arbol("Roble", "Zona Norte", "Templado", 20);
            jardin.agregarPlanta(roble2);
           

        } catch (PlantaDuplicadaException e) {
            System.out.println("Error al agregar planta: " + e.getMessage());
        }

        try {
            
            jardin.agregarPlanta(new Arbusto("Hiedra", "Zona Sur", "Templado", 7));
            jardin.agregarPlanta(new Flor("Rosa", "Zona Este", "Templado", Temporada.PRIMAVERA));
            jardin.agregarPlanta(new Flor("Girasol", "Zona Oeste", "Calido", Temporada.VERANO));
        } catch (PlantaDuplicadaException e) {
            System.out.println("Error al agregar planta: " + e.getMessage());
        }

        /*Mostrar plantas */
        System.out.println("\n--- Mostrar todas las plantas registradas ---");
        jardin.mostrarPlantas();

        /*Podar plantas*/
        System.out.println("\n--- Poda de plantas ---");
        jardin.podarPlantas();

        /*Filtrar por temporada*/
        System.out.println("\n--- Flores que florecen en PRIMAVERA ---");
        jardin.filtrarPorTemporadaFlorecimiento(Temporada.PRIMAVERA);
    }
}    

