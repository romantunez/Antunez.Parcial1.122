package antunez.parcial1.pkg122;
import java.util.ArrayList;


public class JardinBotanico {
    
    private ArrayList<Planta> plantas;

    public JardinBotanico() {
        plantas = new ArrayList<>();
    }

    public void agregarPlanta(Planta planta) throws PlantaDuplicadaException {
        for (Planta p : plantas) {
            if (p.getNombre().equalsIgnoreCase(planta.getNombre()) &&
                p.getUbicacion().equalsIgnoreCase(planta.getUbicacion())) {
                throw new PlantaDuplicadaException("Planta duplicada: " + planta.getNombre() + " en " + planta.getUbicacion());
            }
        }
        plantas.add(planta);
        System.out.println("Planta agregada: " + planta.getNombre());
    }

    public void mostrarPlantas() {
        System.out.println("Plantas registradas en el jardin:");
        for (Planta p : plantas) {
            System.out.println(p.toString());
        }
    }

    public void podarPlantas() {
        System.out.println("Podando plantas...");
        for (Planta p : plantas) {
            if (p instanceof Arbol) {
                ((Arbol) p).podar();
            } else if (p instanceof Arbusto) {
                ((Arbusto) p).podar();
            } else {
                System.out.println("La planta " + p.getNombre() + " no se puede podar.");
            }
        }
    }

    public ArrayList<Flor> filtrarPorTemporadaFlorecimiento(Temporada temporada) {
        ArrayList<Flor> floresFiltradas = new ArrayList<>();
        System.out.println("Flores florecidas en " + temporada + ":");
        for (Planta p : plantas) {
            if (p instanceof Flor) {
                Flor f = (Flor) p;
                if (f.getTemporada() == temporada) {
                    floresFiltradas.add(f);
                    System.out.println(f.toString());
                }
            }
        }
        return floresFiltradas;
    }
}

