
package antunez.parcial1.pkg122;

enum Temporada {
    PRIMAVERA, 
    VERANO, 
    OTOÑO, 
    INVIERNO
}