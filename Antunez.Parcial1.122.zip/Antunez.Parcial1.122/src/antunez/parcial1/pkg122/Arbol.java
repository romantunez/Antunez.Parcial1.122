
package antunez.parcial1.pkg122;


public class Arbol extends Planta implements Podable, Aroma{
    
    private double alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, double alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    public void podar() {
        System.out.println("Podando arbol " + getNombre());
    }

    public void desprenderAroma() {
        System.out.println("El arbol " + getNombre() + " esta desprendiendo aroma.");
    }

    @Override
    public String toString() {
        return super.toString() + ", Altura maxima: " + alturaMaxima + " m";
    }
}
    

