
package antunez.parcial1.pkg122;

class PlantaDuplicadaException extends Exception {
    public PlantaDuplicadaException(String mensaje) {
        super(mensaje);
    }
}